public interface Warplane 
{
	public String country = "NA";
	
	void setCountry(String country);
	String getCountry();
	
	void fireWeapon();
	// just create a simple text message on what type of weapon this plane will fire
	
}