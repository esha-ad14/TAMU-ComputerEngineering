#include "TemperatureDatabase.h"
#include <fstream>
#include <sstream>
#include <vector>
# include <cmath>



using namespace std;

// Default constructor/destructor. Modify them if you need to.
TemperatureDatabase::TemperatureDatabase() {}
TemperatureDatabase::~TemperatureDatabase() {}


void TemperatureDatabase::loadData(const string& filename) {
	// Implement this function for part 1
	cout << "load data" << endl;

	bool checker = true;
	string id= "";
	int year=0;
	int month =0;
	double temperature = 0.0;
	string data = "";

	ifstream file;
	file.open(filename);
	if(!file.is_open()){
		cout << "Error: Can't open file: " << filename << endl;

	}
	else{
		while(getline(file, data)){
			istringstream iss(data);
			iss >> id;
			iss >> year;
			iss >> month;
			iss >> temperature;


			if(iss.fail()){
				checker = false;
				cout << "Error: Other invalid input." << endl;
			}
			if(year <1800 || year >2020){
				checker = false;
				cout << "Error: Invalid year " << year <<endl;

			}
			if(month < 1 || month > 12){
				checker = false;
				cout << "Error: Invalid month " <<month <<endl;

			}
			if((temperature < -50.0 && temperature != -99.99) || temperature > 50.0){
				checker = false;
				cout << "Error: Invalid temperature " <<temperature <<endl;

			}
			if(checker){
				records.insert(id, year, month, temperature);
			}
		}
	}
	//cout << "load data 2" << endl;
	file.close();
	//cout << "load data 3" << endl;
	//exit(0);
}

// Do not modify
void TemperatureDatabase::outputData(const string& filename) {
	cout << "out put" << endl;
	ofstream dataout("sorted." + filename);

	if (!dataout.is_open()) {
		cout << "Error: Unable to open " << filename << endl;
		exit(1);
	}
	dataout << records.print();
}


void TemperatureDatabase::performQuery(const string& filename) {
	// Implement this function for part 2
	string id = "";
	string query = "";
	string line="";
	int start_yr=0;
	int end_yr=0;
	int mode=0;
	double average= 0;


	ifstream inFS;
	ofstream out_file;

	inFS.open(filename);
	out_file.open("result.dat");

	if(!inFS.is_open()){
		cout << "Error: not able to open: " << filename << ".dat" << endl;
		exit(1);
	}

	while (getline(inFS, line)){
		bool validyr=true;
		stringstream iSS(line);
		iSS >> id >> query >> start_yr >> end_yr;


		if(iSS.fail()){
			cout << "Error: Other invalid query" << endl;
		}
		if (query != "MODE" && query != "AVG") {
      cout << "Error: Unsupported query " << query << endl;

    }
		if (start_yr > 2018 || start_yr < 1800) {
			cout << "Error: Invalid range " <<start_yr << "-" << end_yr << endl;
			validyr=false;
    }
		if (end_yr > 2018 || end_yr < 1800) {
			cout << "Error: Invalid range " << start_yr << "-" << end_yr << endl;
			validyr=false;
    }
		if (start_yr > end_yr) {
			cout << "Error: Invalid range " << start_yr << "-" << end_yr << endl;
			validyr=false;
		}
		if (validyr){
			if(query == "AVG"){
				average = records.tempAverage(id,start_yr,end_yr);
				//cout<< id << " " << start_yr << " " << end_yr;
				if (average == -99.99){
					out_file << id << " " << start_yr << " " << end_yr << " " << query << " ";
					out_file << "unknown" << endl;
				}
				else{
					out_file << id << " " << start_yr << " " << end_yr << " " << query << " ";
					out_file << average << endl;
				}
			}
			if(query == "MODE"){
				mode = records.tempMode(id,start_yr,end_yr);
				if (mode == -99){
					out_file << id << " " << start_yr << " " << end_yr << " " << query << " ";
					out_file << "unknown" << endl;
				}
				else{
					out_file << id << " " << start_yr << " " << end_yr << " " << query << " ";
					out_file << mode << endl;
				}
			}
		}
	}
}
