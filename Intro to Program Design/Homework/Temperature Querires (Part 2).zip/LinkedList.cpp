
#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
#include <vector>
#include "LinkedList.h"
#include "Node.h"

using namespace std;

LinkedList::LinkedList(): head(nullptr), tail(nullptr) {
	// Implement this function
}

LinkedList::~LinkedList() {
	// Implement this function
	clear();
}

LinkedList::LinkedList(const LinkedList& source): head(nullptr), tail(nullptr) {
	// Implement this function
	Node* currentVal = source.head;
	Node* previousVal = nullptr;

	while (currentVal != nullptr){
		Node* newNode= new Node(*currentVal);
		if( head ==  nullptr){
			head = newNode;
		}
		if(previousVal !=  nullptr){
			previousVal->next= newNode;
		}
		previousVal = newNode;
		currentVal = currentVal->next;
	}
	tail=previousVal;
}

LinkedList& LinkedList::operator=(const LinkedList& source) {
	// Implement this function
	if(this != &source){
		this->clear();

		Node* currentVal=source.head;
		Node* previousVal = nullptr;

		while(currentVal != nullptr){
			Node* newNode= new Node(*currentVal);

			if( head ==  nullptr){
				head = newNode;
			}
			if(previousVal !=  nullptr){
				previousVal->next= newNode;
			}
			previousVal = newNode;
			currentVal = currentVal->next;
		}
		tail=previousVal;
	}
	return *this;
}

void LinkedList::insert(string location, int year, int month, double temperature) {
	// Implement this function
	Node* newNode = new Node(location, year, month, temperature);
	if( head ==  nullptr){
		head = newNode;
	}
	else{
		Node* currentVal= head;
		Node* previousVal = nullptr;

		while(currentVal != nullptr){
			if(currentVal->data.id > newNode->data.id){
				break;
			}
			else if(currentVal->data.id == newNode->data.id && currentVal->data.year > newNode->data.year){
				break;
			}
			/*
			else if(currentVal->data.year == newNode->data.year&& currentVal->data.month >= newNode->data.month){
        		break;
			}
			*/
			else {
				previousVal = currentVal;
				currentVal = currentVal->next;
      }
		}
		if(currentVal == head){
			newNode->next =head;
			head = newNode;
		}
		else{
			newNode->next = currentVal;
			previousVal->next = newNode;
		}
	}
}

void LinkedList::clear() {
	// Implement this function
	Node* tempNode = nullptr;

	while(head != nullptr){
		tempNode = head-> next;
		delete head;
		head = tempNode;
	}
	head = nullptr;
	tail =  nullptr;
}

Node* LinkedList::getHead() const {
	// Implement this function it will be used to help grade other functions
	return head;
}

string LinkedList::print() const {
	string outputString;
	// Implement this function
	Node* currentVal = head;

	while(currentVal != nullptr){
		stringstream ss;
		ss << currentVal->data.year << " " << currentVal->data.month << " " << currentVal->data.temperature;
    string outStr = ss.str();
    outputString = outputString + currentVal->data.id + " " + outStr + "\n";
    currentVal = currentVal->next;
	}
	return outputString;
}

double LinkedList::tempAverage(string id, int start_yr, int end_yr){
	int counter =0;
	double sum = 0.0;
	Node* currentVal = head;

	while(currentVal != nullptr){
		if(id == currentVal->data.id && currentVal->data.year >= start_yr && currentVal->data.year <= end_yr){
			break;
		}
		currentVal = currentVal-> next;
	}
	if(currentVal == nullptr){
		return -99.99;
	}
	while(currentVal != nullptr && currentVal->data.id == id && currentVal->data.year <= end_yr){
		if (currentVal->data.temperature != -99.99){
			counter++;
			sum+=currentVal->data.temperature;
		}
		currentVal = currentVal->next;
	}
	if (sum == 0){
		return -99.99;
	}
	return (sum/counter);
}

int LinkedList::tempMode(string id, int start_yr, int end_yr){
	int val[101] = {0};
	Node* currentVal = head;
	int counter = 0;
	int maximum = 0;
	int index = 0;

	while(currentVal != nullptr){
		if(id == currentVal->data.id && currentVal->data.year >= start_yr && currentVal->data.year <= end_yr){
			break;
		}
		currentVal = currentVal-> next;
	}
	if(currentVal == nullptr){
		return -99;
	}
	while(currentVal != nullptr && currentVal->data.id == id && currentVal->data.year <= end_yr){
		if (currentVal->data.temperature != -99.99){
			int j = round(currentVal->data.temperature)+50;
			val[j]++;
		}
		currentVal = currentVal->next;
	}
	for(int i=0; i<100; i++){
		if (maximum <= val[i]){
			maximum = val[i];
			index =i;
		}
	}
	if (maximum == 0){
		return -99;
	}
	return index - 50;
}

ostream& operator<<(ostream& os, const LinkedList& ll) {
	/* Do not modify this function */
	os << ll.print();
	return os;
}
