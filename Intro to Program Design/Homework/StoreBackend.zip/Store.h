#ifndef STORE_H
#define STORE_H

#include <vector>
#include <string>


#include "Product.h"
#include "Customer.h"

using namespace std;

class Store{
  string name;
  vector<Product> products;
  vector<Customer> customers;

public:
  Store();
  Store(string name);
  string getName() const;
  void setName(string name);
  void addProduct(int productID, string productName);
  Product& getProduct(int productID);
  void addCustomer(int customerID, string customerName, bool credit=false);
  Customer& getCustomer(int customerID);
  void takeShipment(int productID, int quantity, double cost);
  void takePayment(int customerID, double amount);
  void sellProduct(int customerID, int productID, int quantity);
  string listProducts();
  string listCustomers();
};

#endif
