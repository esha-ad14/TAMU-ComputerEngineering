#ifndef PRODUCT_H
#define PRODUCT_H

#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
//#include <strstream>

using namespace std;

class Product{
  int id;
  int inventory;
  int numSold;
  double totalPaid;
  string name;
  string description;

public:
  Product(int productID, string productName);
  int getID() const;
  string getName() const;
  void setName(string productName);
  string getDescription() const;
  void setDescription(string description);
  int getNumberSold() const;
  double getTotalPaid() const;
  int getInventoryCount() const;
  void addShipment(int shipmentQuantity, double shipmentCost);
  void reduceInventory(int purchaseQuantity);
  double getPrice() const;
};
ostream& operator<< (ostream &os, const Product &prod);
#endif
