#ifndef CUSTOMER_H
#define CUSTOMER_H


#include <vector>
#include <string>


#include "Product.h"

using namespace std;


class Customer{
  int id;
  double balance;
  bool credit;
  string name;
  vector<Product> productsPurchased;

public:
  Customer(int customerID, string name, bool credit =false);
  int getID() const;
  string getName() const;
  void setName(string name);
  bool getCredit() const;
  void setCredit(bool hasCredit);
  double getBalance() const;
  void processPayment(double amount);
  void processPurchase(double amount, Product product);
  string getProductsPurchased() const;
};
ostream& operator<<(ostream& os, const Customer& cust);


#endif
