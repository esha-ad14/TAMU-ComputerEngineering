#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <limits>
//#include <strstream>
#include <sstream>
#include <stdexcept>

#include "Product.h"
#include "Customer.h"
#include "Store.h"

using namespace std;


int main() {

	try {
    Store s;
    Store sto("Buy items");
//Product class
    s.addProduct(345, "soap");
    s.getProduct(345).setDescription("For cleaning.");
    cout << "Product " << endl;
    cout << "id: " << s.getProduct(345).getID() << endl;
    cout << "name: " << s.getProduct(345).getName() << endl;
    cout << "inventory: " << s.getProduct(345).getInventoryCount() << endl;
    cout << "total paid: " << s.getProduct(345).getTotalPaid() << endl;
    cout << "number sold: " << s.getProduct(345).getNumberSold() << endl;
    cout << "description: " << s.getProduct(345).getDescription() << endl;


//Customer class
  s.addCustomer(5664, "Tedd Parker", true);
  cout << "Customer" << endl;
  cout << "Customer id: " << s.getCustomer(5664).getID() << endl;
  cout << "Customer name: " << s.getCustomer(5664).getName() << endl;
  cout << "credit: " << s.getCustomer(5664).getCredit() << endl;
  cout << "balance: " << s.getCustomer(5664).getBalance() << endl;
  cout << "products purchased: " << s.getCustomer(5664).getProductsPurchased() << endl;
//shipment
  s.takeShipment(345, 324, 546);
  cout << endl << "Product (changed prod) " << endl;
  cout << "id: " << s.getProduct(345).getID() << endl;
  cout << "name: " << s.getProduct(345).getName() << endl;
  cout << "inventory: " << s.getProduct(345).getInventoryCount() << endl;
  cout << "total paid: " << s.getProduct(345).getTotalPaid() << endl;
  cout << "number sold: " << s.getProduct(345).getNumberSold() << endl;
  cout << "description: " << s.getProduct(345).getDescription() << endl;
//takePayment

  s.takePayment(5664, 230);
  cout << endl << "Customer " << endl;
  cout << "Customer id: " << s.getCustomer(5664).getID() << endl;
  cout << "Customer name: " << s.getCustomer(5664).getName() << endl;
  cout << "credit: " << s.getCustomer(5664).getCredit() << endl;
  cout << "balance: " << s.getCustomer(5664).getBalance() << endl;
  cout << "products purchased: " << s.getCustomer(5664).getProductsPurchased() << endl;

//sell product
  s.sellProduct(5664,345,12);
  cout << endl << "Customer (buys something)" << endl;
  cout << "Customer id: " << s.getCustomer(5664).getID() << endl;
  cout << "Customer name: " << s.getCustomer(5664).getName() << endl;
  cout << "credit: " << s.getCustomer(5664).getCredit() << endl;
  cout << "balance: " << s.getCustomer(5664).getBalance() << endl;
  cout << "products purchased: " << endl << s.getCustomer(5664).getProductsPurchased() << endl;

  cout << "After soap sold " << endl;
  cout << "id: " << s.getProduct(345).getID() << endl;
  cout << "name: " << s.getProduct(345).getName() << endl;
  cout << "inventory: " << s.getProduct(345).getInventoryCount() << endl;
  cout << "total paid: " << s.getProduct(345).getTotalPaid() << endl;
  cout << "number sold: " << s.getProduct(345).getNumberSold() << endl;
  cout << "description: " << s.getProduct(345).getDescription() << endl;

  cout << s.listProducts();
}
  catch (runtime_error&exc) {
        cout << "Exception caught: "<< exc.what() << endl;
    }
}
