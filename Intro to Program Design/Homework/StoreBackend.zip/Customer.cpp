#include <ostream>
#include <sstream>

#include "Customer.h"
//#include "Product.h"


using namespace std;

Customer::Customer(int customerID, string name, bool credit): id(customerID), name(name), credit(credit), balance(0){
  if(name.size()==0){
    throw runtime_error("Name can't be an empty string");
  }
}

int Customer::getID() const{
  return id;
}
string Customer::getName() const{
  return name;
}
void Customer::setName(string name){
  if(name.size()==0){
    throw runtime_error("Name can't be an empty string");
  }
  this->name = name;

}
bool Customer::getCredit() const{
  return credit;
}
void Customer::setCredit(bool hasCredit){
  this-> credit = hasCredit;
}
double Customer::getBalance() const{
  return balance;
}
void Customer::processPayment(double amount){
  if(amount < 0){
    throw runtime_error("Negative amount added to balance");
  }
  this->balance += amount;
}
void Customer::processPurchase(double amount, Product product){
  //bool pastProduct = false;
  if(amount<0){
    throw runtime_error("Negative amount added to balance");
  }
  this->balance -=amount;
  if(!credit){
    if(balance<0){
      throw runtime_error("Balance can't be negative when credit is false.");
    }
  }
  this->productsPurchased.push_back(product);
}
string Customer::getProductsPurchased() const{
  //std::string s = std::to_string(id);
  ostringstream purchased;
  if (productsPurchased.size() == 0){
     return purchased.str();
  }
 for (int i = 0; i < productsPurchased.size(); ++i) {
     purchased << "Product Name: " << productsPurchased.at(i).getName() << endl;
     purchased << "Product ID: " << productsPurchased.at(i).getID();
     purchased << endl << endl;
 }
 return purchased.str();
}


ostream& operator<< (ostream& os, const Customer& cust){
  os<< "Customer Name: " << cust.getName() << endl;
  os<< "Customer ID: " << cust.getID() << endl;
  if(cust.getCredit()){
    os << "Has Credit: true" << endl;
  }
  else{
    os << "Has Credit: false" << endl;
  }
  os<< "Balance: " << cust.getBalance() << endl;
  os<< "Products Purchased --" << endl<<endl;
  os<<cust.getProductsPurchased();
  return os;
}
