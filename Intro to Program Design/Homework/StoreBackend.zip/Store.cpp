
#include "Store.h"
//#include "Product.h"
//#include "Customer.h"

using namespace std;

Store::Store(){}
Store::Store(string name): name(name){
//  if(name.size() ==){
//    throw runtime_error("Store can't be empty string");
//  }
}
string Store::getName() const{
  return name;
}
void Store::setName(string name){
  this->name = name;
}
void Store::addProduct(int productID, string productName){
  for(int i =0; i < products.size(); i++){
    if(products.at(i).getID()== productID){
      throw runtime_error("ProductID already exists.");
    }
  }
  Product newProduct(productID, productName);
  this->products.push_back(newProduct);
}
Product& Store::getProduct(int productID){
  bool check = true;
  for(int i =0; i < products.size(); i++){
    if(products.at(i).getID()== productID){
      check =false;
      return products.at(i);
    }

  }
  if(check){
    throw runtime_error("Could not find product.");
  }

}
void Store::addCustomer(int customerID, string customerName, bool credit){
    for(int i =0; i < customers.size(); i++){
      if(customers.at(i).getID()== customerID){
        throw runtime_error("customerID is already used.");
      }
    }
    Customer newCustomer(customerID, customerName, credit);
    this->customers.push_back(newCustomer);
}

Customer& Store::getCustomer(int customerID){
  bool check = true;
  for(int i =0; i < customers.size(); i++){
    if(customers.at(i).getID()== customerID){
      check = false;
      return customers.at(i);
    }

  }
  if(check){
    throw runtime_error("Could not find customer.");
  }
}

//here
void Store::takeShipment(int productID, int quantity, double cost){
  bool check = true;
  for(int i =0; i < products.size(); i++){
    if(productID == products.at(i).getID()){
      check = false;
      products.at(i).addShipment(quantity, cost);
    }
  }
  if(check){
    throw runtime_error("Product not in the list.");
  }
}

void Store::takePayment(int customerID, double amount){
  bool check = true;
  for(int i =0; i < customers.size(); i++){
    if(customerID == customers.at(i).getID()){
      check = false;
     customers.at(i).processPayment(amount);
    }
  }
  if(check){
    throw runtime_error("Customer not found.");
  }
}

void Store::sellProduct(int customerID, int productID, int quantity){
  getCustomer(customerID).processPurchase(getProduct(productID).getPrice()* quantity,getProduct(productID));
  getProduct(productID).reduceInventory(quantity);
}

string Store::listProducts(){
  stringstream out;
  for(int i=0; i<products.size(); ++i){
    out << products.at(i);
    if(i != products.size()-1){
      out << endl;
    }
  }
  return out.str();
}
string Store::listCustomers(){
  stringstream out;
  for(int i=0; i < customers.size(); ++i){
    out << customers.at(i);
    //if(i != customers.size()-1){
      out << endl;
    //}
  }
  return out.str();
}
