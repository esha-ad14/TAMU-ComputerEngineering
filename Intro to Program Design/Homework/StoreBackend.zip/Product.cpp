#include <string>

#include "Product.h"

using namespace std;

Product::Product(int productID, string productName): id(productID), name(productName), inventory(0), numSold(0), totalPaid(0.0){
  if(name.size()==0){
    throw runtime_error("Name can't be an empty string");
  }
}
int Product::getID() const{
  return id;
}
string Product::getName() const{
  return name;
}
void Product::setName(std::string productName){
  if(productName.size()==0){
    throw runtime_error("Name can't be an empty string");
  }
  this->name = productName;

}
string Product::getDescription() const{
  return description;
}
void Product::setDescription(string description){
  this->description = description;
}
int Product::getNumberSold() const{
  return numSold;
}
double Product::getTotalPaid() const{
  return totalPaid;
}
int Product::getInventoryCount() const{
  return inventory;
}
void Product::addShipment(int shipmentQuantity, double shipmentCost){
  if(shipmentQuantity < 0 || shipmentCost < 0){
    throw runtime_error("Shipment quantity or shipment cost is negative");
  }
  this->inventory += shipmentQuantity;
  this->totalPaid += shipmentCost;
}
void Product::reduceInventory(int purchaseQuantity){
  if(purchaseQuantity < 0){
    throw runtime_error("Negative purchaseQuantity.");
 }
  if(this->inventory < purchaseQuantity ){
    throw runtime_error("Not enough inventory.");
  }
  this->inventory -= purchaseQuantity;
  this->numSold += purchaseQuantity;
}
double Product::getPrice() const{
  if((inventory + numSold)==0){
    throw runtime_error("Price can't be calculated.");
  }
  double price;
  price = (totalPaid / ((double)(inventory + numSold))) * 1.25;
  return price;
}

ostream& operator<< (ostream &os, const Product &prod){
 	os << "Product Name: " << prod.getName()<<endl;
 	os << "Product ID: "<< prod.getID()<<endl;
  os << "Description: "<< prod.getDescription()  <<endl;
  os << "Inventory: "<< prod.getInventoryCount() <<endl;
  os << "Number Sold: "<< prod.getNumberSold() <<endl;
  os << "Total Paid: "<< prod.getTotalPaid() <<endl;
  bool errorPr =false;
  try{
    prod.getPrice();
  }
  catch(runtime_error&exc){
    os << "Price: Unavailable" <<endl<<endl;
    errorPr =true;
  }
  if(!errorPr){
    os << "Price: "<< prod.getPrice() <<endl;
  }
  return os;
}
