#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include <climits>
#include "functions.h"
using namespace std;

int main() {
	int rows = 0;
	int cols = 0;
	string infilename;
	cin >> rows >> cols;
	// check for negative values for rows cols, stream state will be fail if non-integer is encountered
	if (!cin.good() || rows <=0 || cols <=0) {
		cout << "Error: Problem reading in rows and columns." << endl;
		return 1;
	}
	cin >> infilename;
	ifstream infs(infilename);
	if (!infs.is_open()) {
		cout << "Error: Unable to open file " << infilename << endl;
		return 1;
	}
	// if we get this far then stream is good
	vector<vector<int>> elevations = vector<vector<int>>(rows, vector<int>(cols,0));
	vector<vector<int>> reds = vector<vector<int>>(rows, vector<int>(cols,0));
	vector<vector<int>> greens = vector<vector<int>>(rows, vector<int>(cols,0));
	vector<vector<int>> blues = vector<vector<int>>(rows, vector<int>(cols,0));

	int dataCount = 0;

	// Read elevations from file
	cout << "Reading Values..." << endl;
	cout << "Expecting " << rows * cols << " points" << endl;
	for (int i=0; i<rows; ++i) {
		for (int j=0; j<cols; ++j) {
			int elev;
			infs >> elev;
			dataCount++;
			if (infs.fail()) {
				cout << "Error: Read a non-integer value." << endl;
				return 1;
			}
			if (infs.bad()) {
				cout << "Error: Problem reading the file." << endl;
				return 1;
			}
			if (infs.eof()) {
				if (dataCount < rows*cols) {
					cout << "Error: End of file reached prior to getting all required data." << endl;
					cout << "Read in " << dataCount << " of expected " << rows*cols << endl;
					return 1;
				}
			}
			elevations.at(i).at(j) = elev;
		}
	}
	cout << dataCount << " elevations read in." << endl;
	int extraData = 0;
	if (infs >> extraData) {
		cout << "Error: Too many data points" << endl;
		return 1;
	}


	// find max and min
	cout << "Finding max and min" << endl;
	// initialize max and min to first element in vector
	int min = elevations.at(0).at(0);
	int max = elevations.at(0).at(0);

	for (int i=0; i<rows; ++i) {
		for (int j=0; j<cols; ++j) {
			if (elevations.at(i).at(j)<min)
				min = elevations.at(i).at(j);
			if (elevations.at(i).at(j)>max)
				max = elevations.at(i).at(j);
		}
	}

	cout << "Max elevation: " << max << endl;
	cout << "Min elevation: " << min << endl;

	cout << "Scaling values... " << endl;

	// scale values and add to RGB vectors
	for (int i=0; i<rows; ++i) {
		for (int j=0; j<cols; ++j) {
			int RGBval = round(static_cast<double>((elevations.at(i).at(j)-min)*255)/(max - min));
			reds.at(i).at(j) = greens.at(i).at(j) = blues.at(i).at(j) = RGBval;
		}
	}

//Color path implementation
//variables
	int dist = 0;
	int color_r =252;
	int color_g =25;
	int color_b =63;
  vector<int> shortestPath;
	for(int start_row =0; start_row < rows; start_row++){
		dist = colorPath(elevations, reds, greens, blues, color_r, color_g, color_b, start_row);
		shortestPath.push_back(dist);
	}
	int minPath = INT_MAX;
	for(int i=0; i<shortestPath.size(); i++){
		if(minPath > shortestPath.at(i)){
			minPath=shortestPath.at(i);
		}
	}
	for(int i=0; i<shortestPath.size(); i++){
		if(shortestPath.at(i) == minPath){
			colorPath(elevations, reds, greens, blues, 31, 253, 13, i);
		}
	}

	ofstream ofs(infilename+".ppm");
	if (!ofs.is_open()) {
		cout << "Error: Unable to open output file." << endl;
		return 1;
	}

	cout << "Outputting file" << endl;
	ofs << "P3" << endl;
	ofs << cols << " " << rows << endl;
	ofs << 255 << endl;
	for (int i=0; i<rows; ++i) {
		for (int j=0; j<cols; ++j) {
			ofs << reds.at(i).at(j) << " ";
			ofs << greens.at(i).at(j) << " ";
			ofs << blues.at(i).at(j) << " ";
		}
		ofs << endl;
	}

	cout << "finished" << endl;

}
