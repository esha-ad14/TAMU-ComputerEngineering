#include<vector>
#include <cmath>
#include "functions.h"

using namespace std;

int colorPath(const vector<vector<int>>& heightMap, vector<vector<int>>& r, vector<vector<int>>& g, vector<vector<int>>& b, int color_r, int color_g,
int color_b, int start_row) {
  //variables
	int dist = 0;
  int forwardPath=0;
  int absFowStep=0;
  int start_col=0;
  int downPath=0;
  int absDownStep=0;
  int upPath =0;
  int absUpStep=0;
  int map=heightMap.size();

  //vectors
  vector<vector<int>> r_val =r;
  vector<vector<int>> g_val =g;
  vector<vector<int>> b_val =b;

  r.at(start_row).at(start_col) = color_r;
  g.at(start_row).at(start_col) = color_g;
  b.at(start_row).at(start_col) = color_b;

  while(start_col < heightMap[start_row].size()-1){
    if(start_row == 0){
      forwardPath = heightMap.at(start_row).at(start_col+1);
      absFowStep = abs(forwardPath - heightMap.at(start_row).at(start_col));
      upPath = heightMap.at(start_row).at(start_col+1);
      absUpStep = abs(upPath - heightMap.at(start_row).at(start_col));
      downPath = heightMap.at(start_row+1).at(start_col+1);
      absDownStep = abs(downPath - heightMap.at(start_row).at(start_col));
    }
    else if(start_row == map -1){
      forwardPath = heightMap.at(start_row).at(start_col+1);
      absFowStep = abs(forwardPath - heightMap.at(start_row).at(start_col));
      upPath = heightMap.at(start_row-1).at(start_col+1);
      absUpStep = abs(upPath - heightMap.at(start_row).at(start_col));
      downPath = heightMap.at(start_row).at(start_col+1);
      absDownStep = abs(forwardPath - heightMap.at(start_row).at(start_col));
    }
    else{
      forwardPath = heightMap.at(start_row).at(start_col+1);
      absFowStep = abs(forwardPath - heightMap.at(start_row).at(start_col));
      upPath = heightMap.at(start_row - 1).at(start_col+1);
      absUpStep = abs(upPath - heightMap.at(start_row).at(start_col));
      downPath = heightMap.at(start_row + 1).at(start_col + 1);
      absDownStep = abs(downPath - heightMap.at(start_row).at(start_col));
    }
    if ((absFowStep <= absDownStep) && (absFowStep <= absUpStep)){
      start_col +=1;
      dist = dist + absFowStep;
    }
    else if(((absUpStep < absFowStep) && (absUpStep == absDownStep)) || ((absDownStep < absFowStep) && (absDownStep < absUpStep))){
      start_row+=1;
      start_col+=1;
      dist = dist + absDownStep;
    }
    else if(absUpStep < absFowStep){
      start_row -=1;
      start_col+=1;
      dist = dist + absUpStep;
    }
    r.at(start_row).at(start_col) = color_r;
    g.at(start_row).at(start_col) = color_g;
    b.at(start_row).at(start_col) = color_b;
  }

	return dist;
}
