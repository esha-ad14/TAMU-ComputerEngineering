#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

// read data
vector<int> getData(const string& theFile){
	int elevation;
	vector<int> imageData;
	ifstream dataFile;
	dataFile.open(theFile);
	if (!dataFile.is_open()){
		cout << "Error: The file did not open." << endl;
		exit(EXIT_FAILURE);
	}
	else{
		while (!dataFile.eof()){
			dataFile >> elevation;
			imageData.push_back(elevation);
		}
		dataFile.close();
	}
	return imageData;
}

//This is a Tow D Vector function
vector<vector<int> > twoDvector(const vector<int>& elevation, int row, int col){
	vector<vector<int> > imageData;
	int getCounter = 0;
	for (int i = 0; i < row; i++){
		vector<int> row;
		for (int j = 0; j < col; j++){
			row.push_back(elevation.at(getCounter));
			getCounter++;
		}
		imageData.push_back(row);
	}
	return imageData;
}

//Gets the minimum and maximum values for the 2d vector
void min_max(int& max, int& min, const vector<vector< int> > &imageData, int row, int col){
	max = imageData.at(0).at(0);
	min = imageData.at(0).at(0);
	for (int i = 0; i < row; i++){
		for(int j = 0; j < col; j++){
			if (imageData.at(i).at(j) > max){
				max = imageData.at(i).at(j);
			}
			else if (imageData.at(i).at(j) < min){
				min = imageData.at(i).at(j);
			}
		}
	}
}

//scales down the elevation to rgb values between 0 and 255
vector<vector<int> > scaledVal(const vector<vector<int> > &imageData, double max, double min){
	vector<vector<int> >gr_shades;
	for(int i = 0; i < imageData.size(); i++){
		vector<int> row;
		for(int j = 0; j < imageData[i].size(); j++){
			int shade_of_grey = round(((imageData.at(i).at(j) - min) / (max - min))*255);
			row.push_back(shade_of_grey);
		}
		gr_shades.push_back(row);
	}

	for(int i = 0; i < gr_shades.size(); i++){
		for(int j = 0; j < gr_shades[i].size(); j++){
			cout << gr_shades.at(i).at(j) << " ";
		}
		cout << endl;
	}
	return gr_shades;
}

// puts the color values into a 2d vector
vector<vector<int> > color_2D(const vector<vector<int> > &shade_of_grey){
	vector<vector<int> > rgb;
	for(int i = 0; i < shade_of_grey.size(); i++){
		vector<int> row;
		for(int j = 0; j < shade_of_grey[i].size(); j++){
			row.push_back(shade_of_grey.at(i).at(j));
		}
		rgb.push_back(row);
	}
	return rgb;
}

//prints the 2d vector into a ppm file
void asthePPM(vector<vector<int> > &gr_shades, int row, int col, string theFile, const vector<vector<int> > &Red, const vector<vector<int> > &Green, const vector<vector<int> > &Blue){
	ofstream outputImage;
	string newFile = theFile + ".ppm";
	outputImage.open(newFile);
	if (!outputImage.is_open()){
		cout << "Error: The file did not open." << endl;
		//cout << "EXITING PROGRAM" << endl;
		exit(EXIT_FAILURE);
	}
	else{
		//cout << "File OPENED" << endl;
		cout << "Your .ppm file has been created." << endl;
		cout << "Filename: " << newFile << endl;
		outputImage << "P3" << endl;
		outputImage << col << " " << row << endl;
		outputImage << 255 << endl;
		for(int i = 0; i < gr_shades.size(); i++){
			for(int j = 0; j < gr_shades[i].size(); j++){
				outputImage << Red.at(i).at(j) << " ";
				outputImage << Green.at(i).at(j) << " ";
				outputImage << Blue.at(i).at(j) << " ";
			}
			outputImage << endl;
		}
	}
	outputImage.close();
}

//Main starts here
int main(){
	vector<vector<int> > imageData;
	vector<vector<int> > Red;
	vector<vector<int> > Green;
	vector<vector<int> > Blue;
	int row, col, max, min, checkrow, checkcol;
	string theFile;
	int minimumRow = 0;
	int r = 252;
	int g = 25;
	int b = 63;

	cout << "Enter the number of rows and columns: ";
	cin >> row;
	cin >> col;

	cout << "Enter that file name:";
	cin >> theFile;

	if(row<0 && col<0){
		cout << "Error: Negative number for row and col." << endl;
		exit(EXIT_FAILURE);
 }

	vector<int> elevation = getData(theFile);

	int sizeCheck = row * col;
	while(sizeCheck > elevation.size()){
		int sizeCheck = row * col;
		if(sizeCheck > elevation.size()){
			cout << "Error: Too many data elements for rows and columns." << endl;
			exit(EXIT_FAILURE);

			continue;
		}
		else if(sizeCheck < elevation.size()){
			cout << "Error: Not enough data elements for humber of rows and columns." << endl;
			exit(EXIT_FAILURE);

			continue;
		}
		else
			break;
	}
	imageData = twoDvector(elevation, row, col);

// character check
  vector<vector<int>>  elev = twoDvector(elevation, row, col);
	for (int i = 0; i < row; i++){
		for(int j = 0; j < col; j++){
			cout << isdigit(elev[i][j]) <<endl;
			if(isdigit(elev[i][j])){
				cout << "Error: There were characters in row or column." << endl;
				exit(EXIT_FAILURE);
			}
			else{
				break;
			}
		}
	}


	min_max(max, min, imageData, row, col);
	cout << "Maximum value: " << max << endl;
	cout << "Minimum value: " << min << endl;

	vector<vector<int> > grey_color = scaledVal(imageData, max, min);
	Red = grey_color;
	Green = grey_color;
	Blue = grey_color;

	//cout << "Minimum Row: " << minimumRow << endl;

	asthePPM(grey_color, row, col,theFile, Red, Green, Blue);

}
