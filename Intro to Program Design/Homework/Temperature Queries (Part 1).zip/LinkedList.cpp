
#include <iostream>
#include <string>
#include <sstream>

#include "LinkedList.h"
#include "Node.h"

using namespace std;

LinkedList::LinkedList(): head(nullptr), tail(nullptr) {
	// Implement this function
}

LinkedList::~LinkedList() {
	// Implement this function
	clear();
}

LinkedList::LinkedList(const LinkedList& source): head(nullptr), tail(nullptr) {
	// Implement this function
	Node* currentVal = source.head;
	Node* previousVal = nullptr;

	while (currentVal != nullptr){
		Node* newNode= new Node(*currentVal);
		if( head ==  nullptr){
			head = newNode;
		}
		if(previousVal !=  nullptr){
			previousVal->next= newNode;
		}
		previousVal = newNode;
		currentVal = currentVal->next;
	}
	tail=previousVal;
}

LinkedList& LinkedList::operator=(const LinkedList& source) {
	// Implement this function
	if(this != &source){
		this->clear();

		Node* currentVal=source.head;
		Node* previousVal = nullptr;

		while(currentVal != nullptr){
			Node* newNode= new Node(*currentVal);

			if( head ==  nullptr){
				head = newNode;
			}
			if(previousVal !=  nullptr){
				previousVal->next= newNode;
			}
			previousVal = newNode;
			currentVal = currentVal->next;
		}
		tail=previousVal;
	}
	return *this;
}

void LinkedList::insert(string location, int year, int month, double temperature) {
	// Implement this function
	Node* newNode = new Node(location, year, month, temperature);
	if( head ==  nullptr){
		head = newNode;
	}
	else{
		Node* currentVal= head;
		Node* previousVal = nullptr;

		while(currentVal != nullptr){
			if(currentVal->data.id > newNode->data.id){
				break;
			}
			else if(currentVal->data.id == newNode->data.id && currentVal->data.year > newNode->data.year){
				break;
			}
			else if(currentVal->data.year == newNode->data.year&& currentVal->data.month >= newNode->data.month){
        break;
      }
			else {
				previousVal = currentVal;
				currentVal = currentVal->next;
      }
		}
		if(currentVal == head){
			newNode->next =head;
			head = newNode;
		}
		else{
			newNode->next = currentVal;
			previousVal->next = newNode;
		}
	}
}


void LinkedList::clear() {
	// Implement this function
	Node* tempNode = nullptr;

	while(head != nullptr){
		tempNode = head-> next;
		delete head;
		head = tempNode;
	}
	head = nullptr;
	tail =  nullptr;
}

Node* LinkedList::getHead() const {
	// Implement this function it will be used to help grade other functions
	return head;
}

string LinkedList::print() const {
	string outputString;
	// Implement this function
	Node* currentVal = head;

	while(currentVal != nullptr){
		stringstream ss;
		ss << currentVal->data.year << " " << currentVal->data.month << " " << currentVal->data.temperature;
    string outStr = ss.str();
    outputString = outputString + currentVal->data.id + " " + outStr + "\n";
    currentVal = currentVal->next;
	}
	return outputString;
}

ostream& operator<<(ostream& os, const LinkedList& ll) {
	/* Do not modify this function */
	os << ll.print();
	return os;
}
