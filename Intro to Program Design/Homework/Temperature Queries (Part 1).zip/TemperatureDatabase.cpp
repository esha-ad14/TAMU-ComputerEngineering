#include "TemperatureDatabase.h"

#include <fstream>
#include <sstream>

using namespace std;

// Default constructor/destructor. Modify them if you need to.
TemperatureDatabase::TemperatureDatabase() {}
TemperatureDatabase::~TemperatureDatabase() {}


void TemperatureDatabase::loadData(const string& filename) {
	// Implement this function for part 1


	bool checker = true;
	string id= "";
	int year=0;
	int month =0;
	double temperature = 0.0;
	string data = "";

	ifstream file;
	file.open(filename);
	if(!file.is_open()){
		cout << "Error: Can't open file: " << filename << endl;
	//	exit(1);
	}
	else{
		while(getline(file, data)){
			istringstream iss(data);
			iss >> id;
			iss >> year;
			iss >> month;
			iss >> temperature;

			if(iss.fail()){
				checker = false;
				cout << "Error: Other invalid input." << endl;

				//exit(1);
			}
			if(year <1800 || year >2020){
				checker = false;
				cout << "Error: Invalid year " << year <<endl;

				//exit(1);
			}
			if(month < 1 || month > 12){
				checker = false;
				cout << "Error: Invalid month " <<month <<endl;
			//	exit(1);
			}
			if((temperature < -50.0 && temperature != -99.99) || temperature > 50.0){
				checker = false;
				cout << "Error: Invalid temperature " <<temperature <<endl;
			//	exit(1);
			}
			if(checker){
				records.insert(id, year, month, temperature);
				//exit(1);
			}
		}
	}
	file.close();
	exit(1);
}

// Do not modify
void TemperatureDatabase::outputData(const string& filename) {
	ofstream dataout("sorted." + filename);

	if (!dataout.is_open()) {
		cout << "Error: Unable to open " << filename << endl;
		exit(1);
	}
	dataout << records.print();
}

void TemperatureDatabase::performQuery(const string& filename) {
	// Implement this function for part 2
	//  Leave it blank for part 1
}
