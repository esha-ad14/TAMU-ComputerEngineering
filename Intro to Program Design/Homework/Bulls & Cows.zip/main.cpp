#include <iostream>
#include <vector>
#include <cstdlib>
#include <chrono>
#include <math.h>
#include <algorithm>
using namespace std;

int CodeSize(int code){
  int divCounter=0;
  while (true){
    code/=10;
    divCounter++;
    if(code == 0){
      return divCounter;
    }
  }

}

bool duplicates(int val, int numDigits) {
  vector<int>values(numDigits,0);
  for(int i=0; i<values.size();i++){
      int factor=pow(10,i);
      values[i] = (val/factor)%10;
  }

  for(int i = 0;  i < values.size(); i++){
    int check = values[i];
    for(int j = 0; j < values.size(); j++){
      if(values[j] == check && i!=j){
        return true;
      }
    }
  }

  return false;


}



int main() {
    srand(std::chrono::duration_cast<std::chrono::milliseconds>
     (std::chrono::system_clock::now().time_since_epoch()).count()%2000000000);
    // needed to autograde some test cases in Mimir
	  // do not call srand again in your program

    //get number of digits
    int numDigits;
    int getCode;
    int factor;
    string guess = "";
    string num_to_guess = "";
    int length = 0;
    vector<int>vals;
    int bulls = 0;
    int cows = 0;
    bool correct = false;
    int guessed_val = 0;
    //cout<< "Enter number of digits in code (3, 4 or 5): ";
    //cin>> numDigits;

    //check if its 0,3,4,5
    while (true){
      cout<< "Enter number of digits in code (3, 4 or 5): ";
      cin>> numDigits;
      if(numDigits == 0 || numDigits == 3 || numDigits == 4 || numDigits == 5){
        break;
      }
    }


    // Load Vector with code digit
    if (numDigits == 0){
      cout << "Enter code: ";
      cin >> getCode;


      while (true){
        cout<< "Enter number of digits in code: ";
        cin>> numDigits;
        if(numDigits == 0 || numDigits == 3 || numDigits == 4 || numDigits == 5){
          break;
        }
      }


      int len = CodeSize(getCode);
      if(len != numDigits) {
        vector<int>values(len+(numDigits-len),0);
        for(int i=0; i<values.size();i++){
            factor=pow(10,i);
            values[i] = (getCode/factor)%10;
            if(i==values.size()){
              values[i] = 0;
            }

        }
        reverse(values.begin(),values.end());
        for(int x=1; x < values.size(); x++){
          vals.push_back(values[x]);
        }
        guess = to_string(getCode);
        num_to_guess+="0-";
        for(int i = 0; i < guess.size(); i++) {
            num_to_guess+=guess.at(i);
            if(i != guess.size()-1){
              num_to_guess+="-";
            }
        }
        length = CodeSize(getCode);
      }


      else{
        vector<int>values(len,0);
        for(int i=0; i<values.size();i++){
            factor=pow(10,i);
            values[i] = (getCode/factor)%10;
        }
        reverse(values.begin(),values.end());
        for(int x=0; x < values.size(); x++){
          vals.push_back(values[x]);
        }
        guess = to_string(getCode);
        for(int i = 0; i < guess.size(); i++) {
          num_to_guess+=guess.at(i);
          if(i != guess.size()-1){
            num_to_guess+="-";
          }
        }
      }
      length = CodeSize(getCode);
    }


    else{
        vector<int>values(numDigits,0);
        int val = 0;
        for(int i = 0; i < 1000000000000; i++) {
          val = rand() % 99999 + 0;
          if(CodeSize(val)==numDigits && duplicates(val,numDigits) == false) {
            break;
          }
        }
        //cout << val << endl;
        for(int i=0; i<values.size();i++){
            factor=pow(10,i);
            values[i] = (val/factor)%10;
        }
        reverse(values.begin(),values.end());
        for(int x=0; x < values.size(); x++){
          vals.push_back(values[x]);
        }
        guess = to_string(val);
        for(int i = 0; i < guess.size(); i++) {
            num_to_guess+=guess.at(i);
            if(i!=guess.size()-1){
              num_to_guess+="-";
            }
        }
        length = CodeSize(val);
    }

    //display code to be guessed
    cout << "Number to guess: ";
    cout << num_to_guess << endl;

    //fun stuff

    while(true){
      vector<int>values;
      //check validity
      while(true){
        cout << "Enter Guess: ";
        cin >> guessed_val;

        vector<int>things(CodeSize(guessed_val),0);
        for(int i=0; i<things.size();i++){
            factor=pow(10,i);
            things[i] = (guessed_val/factor)%10;
        }
        reverse(things.begin(),things.end());

        if(things.size()>vals.size() && duplicates(guessed_val,things.size()) == true) {
          cout << "You can only enter "<<numDigits<< " digits." << endl;
        }
        else if(things.size()<vals.size() || duplicates(guessed_val,things.size()) == true){
          cout << "Each number must be different." << endl;

        }
        else if(things.size()>vals.size()){
          cout << "You can only enter "<<numDigits<< " digits." << endl;
        }
        else{
          for(int x=0; x < things.size(); x++){
            values.push_back(things[x]);
          }
          break;
        }
      }



      //bulls and cows
      //rules --> digit is in code and in correct location (bull)
      //rules --> digit is in code and in wrong location (cow)
      //values == guessed and vlas == actual
      //cout << guessed_val << endl

      bulls = 0;
      cows = 0;

      int checker = 0;
      for(int i = 0; i < values.size(); i++) {
        checker = values[i];
        for(int j = 0; j < vals.size(); j++) {
          if(checker == vals[j] && i == j){
            bulls+=1;
          }
          if(checker == vals[j] && i != j) {
            cows+=1;
          }
        }
      }
      if(bulls==vals.size()){
        cout << bulls <<" bulls... " <<num_to_guess <<" is correct!" << endl;
        break;
      }
      cout << bulls << " bulls" << endl;
      cout << cows << " cows" << endl;

    }



  }
