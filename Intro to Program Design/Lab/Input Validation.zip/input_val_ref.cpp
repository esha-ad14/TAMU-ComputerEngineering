#include <iostream>
#include <limits>
using namespace std;

int main() {

	int value = 0;

	while (value != -9) {
		cout << "Enter an integer (or -9 to exit): ";
		cin >> value;
		// EDIT3A uncomment the next line
		if (!cin.good()) {
			// EDIT1 uncomment the next line
			cin.clear();
			// EDIT2 uncomment the next line
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		// EDIT3B uncomment the next line
		}
		// EDIT3C uncomment the next line
		else {
			cout << "You entered: " << value << endl << endl;
		// EDIT3D uncomment the next line
		}

		if (value == -9)
			return 0;
	}


}
//Unexpected Values for different scenarios
// 2) As expected all integer values passed, and any floats or strings did not. Some unexpected values or rather results were the 123 456 while both integers were printed seperately and 9876543210 went in an infinite loop
// 5) As expected all integer values passed, and any floats or strings did not. Some unexpected values or rather results were the 123 456 while both integers were printed seperately, however this time for 9876543210 the result was 2147483647
// 8) As expected all integer values passed, and some floats or strings did not. Some unexpected values/results were the 123asdf, 123 asdf, 123.456, 0.987, 123 456 where it took the initial numbers such as 123 from 123asdf or dropped that values after the decimal and 9876543210 went in an infinite loop
// 11) For all values this time, with both cin.clear() and cin.ignore(), we notice that for any integer returns the given input, floats or strings result in 0, with the values 123asdf, 123 asdf, 123.456, 0.987, 123 456 where it took the initial numbers such as 123 from 123asdf or dropped that values after the decimal, and 9876543210 the result was 2147483647
// 13) As expected all integer values passed, some floats and strings did not in ehich case thi, cout << "Enter an integer (or -9 to exit): ";, for user to keep trying. Some unexpected values kept the same behviour such as, 123asdf, 123 asdf, 123.456, 0.987 where it took the initial numbers such as 123 from 123asdf or dropped that values after the decimal, and , 123 456 resulted in 123 and 456 seperately, and 9876543210, didn't pass letting the user try again
