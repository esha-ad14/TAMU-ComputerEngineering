#ifndef SAVINGS_ACCOUNT_H
#define SAVINGS_ACCOUNT_H
#include "Account.h"

/*  FIXME:
    Create a SavingsAccount class inherited from the Account class.

    Add the data member interest_rate
      type should be double
      set default value of 0.001 in constructor

    This file should contain the class definition and the
    declarations of its member functions.
*/
class SavingsAccount: public Account{

private:
  double interest_rate;

public:
  SavingsAccount(double interest_rate = 0.001);
  SavingsAccount(double interest_rate, double balance);
  //SavingsAccount SavingsAccount(300.0, 0.005);

  double getInterestRate();
  void setInterestRate(double newInterestRate);
  virtual ~SavingsAccount();
};

//FIXME 1: add class definition for SavingsAccount

// FIXME 1A: add data member interest_rate

// FIXME 1B: add default constructor and single parameter constructor

// FIXME 1C: add two parameter constructor

// FIXME 1D: add getter declaration for interest_rate

// FIXME 1E: add setter declaration for interest_rate

#endif
