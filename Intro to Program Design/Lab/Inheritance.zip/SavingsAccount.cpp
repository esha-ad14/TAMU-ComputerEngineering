/*
    This file should contain the member function
    implementations for the SavingsAccount class
*/

#include "SavingsAccount.h"

// FIXME: add the constructors (two if you use a default parameter, three otherwise)
SavingsAccount::SavingsAccount(double interest_rate): Account(){
  this->interest_rate=interest_rate;
}
SavingsAccount::SavingsAccount(double balance, double interest_rate): Account(balance){
  this->interest_rate=interest_rate;
}

// FIXME: add definition for getInterestRate()
double SavingsAccount::getInterestRate(){
  return interest_rate;
}


// FIXME: add definition for setInterestRate(double newRate)
void SavingsAccount::setInterestRate(double newInterestRate){
  this->interest_rate=newInterestRate;
}
SavingsAccount::~SavingsAccount(){}
