#include "Node.h"
#include<iostream>

std::ostream& operator<<(std::ostream& os, const Node& n) {
   os << n.value;
   return os;
}
