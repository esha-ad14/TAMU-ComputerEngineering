
#ifndef VOLUME_H
#define VOLUME_H

#include <iostream>


//const double pi = 3.14;

// Volume of a sphere: 4/3 pi r^3
double volume(double r);

// Volume of a cube: a^3
double volume(int a);

// Volume of a cylinder: (pi r^2) * h [area of circle times height]
double volume(double r, int h);

#endif
