#ifndef LIBRARY_H
#define LIBRARY_H

#include <iostream>


int getRange(int maxVal, int minVal, std::string prompt);

void processChoice(int choice);

void printMenu();

#endif
