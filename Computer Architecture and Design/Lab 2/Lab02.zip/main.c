extern long long int test();
extern long long int lab02b();
extern void lab02c(long long int a);
extern void lab02d(long long int b);

int main(void)
{
	test();
	lab02b();
	lab02c(255);
	lab02d(10);

    return 0;
}
